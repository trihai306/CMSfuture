
<header class="navbar-expand-md">
    @livewire('core::admin.menu-header')
</header>
