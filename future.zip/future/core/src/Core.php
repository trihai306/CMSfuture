<?php

namespace Future\Core;

class Core
{
    // Build wonderful things
}