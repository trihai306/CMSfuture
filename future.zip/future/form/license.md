# The license

Copyright (c) Hai Nguyen <haidev306@gmail.com>

...Add your license text here...