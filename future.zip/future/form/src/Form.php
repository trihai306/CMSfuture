<?php

namespace Future\Form;

class Form
{
    // Build wonderful things
}