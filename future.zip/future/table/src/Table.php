<?php

namespace Future\Table;

class Table
{
    // Build wonderful things
}